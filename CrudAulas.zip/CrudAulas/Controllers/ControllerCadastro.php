<?php
include_once 'Variaveis.php';
include_once 'ClassCrud.php';

$Crud = new ClassCrud();

if ($Acao == 'Entra') {
    // Variáveis relacionadas ao cadastro de quartos
    $TipoQuarto = filter_input(INPUT_POST, 'TipoQuarto', FILTER_SANITIZE_STRING);
    $DescricaoQuarto = filter_input(INPUT_POST, 'DescricaoQuarto', FILTER_SANITIZE_STRING);
    $Ocupado = filter_input(INPUT_POST, 'Ocupado', FILTER_SANITIZE_NUMBER_INT);

    $Crud->insertQuarto($TipoQuarto, $DescricaoQuarto, $Ocupado);
} elseif ($Acao == 'Atualizar') {
    // Variáveis relacionadas à atualização de registros (no contexto dos quartos ou de acordo com o seu sistema)
    $CodigoProduto = filter_input(INPUT_POST, 'CodigoProduto', FILTER_SANITIZE_STRING);
    $NomeProduto = filter_input(INPUT_POST, 'NomeProduto', FILTER_SANITIZE_STRING);
    $PrecoProduto = filter_input(INPUT_POST, 'PrecoProduto', FILTER_SANITIZE_STRING);
    $QuantidadeEstoque = filter_input(INPUT_POST, 'QuantidadeEstoque', FILTER_SANITIZE_NUMBER_INT);

    // Aqui, você deve determinar qual tabela do banco de dados você está atualizando (cadastro, quartos, etc.)
    // Certifique-se de ajustar a tabela, os campos e a condição de atualização de acordo com o seu sistema.
    // O exemplo abaixo assume a atualização na tabela "cadastro" com base no ID.
    $Crud->updateRegistro("cadastro", "CodigoProduto=?, NomeProduto=?, PrecoProduto=?, QuantidadeEstoque=?", 
    "id=?", array($CodigoProduto, $NomeProduto, $PrecoProduto, $QuantidadeEstoque, $Id));
}

// Redireciona de volta para a página de cadastro após a conclusão da operação
header("Location: cadastro.php");
?>
