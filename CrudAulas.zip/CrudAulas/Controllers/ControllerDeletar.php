<?php
include 'ClassCrud.php';

$Crud = new ClassCrud();
$IdProduto = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_SPECIAL_CHARS);
$Crud->deleteRegistro("cadastro", "id=?", array($IdProduto));
header("Location: ../selecao.php");
?>
