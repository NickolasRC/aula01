<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style.css">
</head>
<body>
    <div class="Banner">
       <img src="Images/Banner.jpg" alt="Logo Senai">
    </div>
    <div class="Nav">
        <li><a href="cadastro.php">Cadastro Cliente e Quarto</a></li>
        <li><a href="selecao.php">Lista de Quartos e Clientes</a></li>
        <li><a href="movimentacao.php">Estoque</a></li>
        <li><a href="hotel_financeiro.php">Financeiro</a></li>
    </div>
    