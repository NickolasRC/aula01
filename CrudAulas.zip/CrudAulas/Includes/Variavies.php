<php
if (isset($_POST['Acao'])) {
    $Acao = filter_input(INPUT_POST, 'Acao', FILTER_SANITIZE_SPECIAL_CHARS);
} elseif (isset($_GET['Acao'])) {
    $Acao = filter_input(INPUT_GET, 'Acao', FILTER_SANITIZE_SPECIAL_CHARS);
} else {
    $Acao = "";
}

if (isset($_POST['Id'])) {
    $Id = filter_input(INPUT_POST, 'Id', FILTER_SANITIZE_SPECIAL_CHARS);
} elseif (isset($_GET['Id'])) {
    $Id = filter_input(INPUT_GET, 'Id', FILTER_SANITIZE_SPECIAL_CHARS);
} else {
    $Id = 0;
}

// Variáveis relacionadas aos quartos
$TipoQuarto = isset($_POST['TipoQuarto']) ? filter_input(INPUT_POST, 'TipoQuarto', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$DescricaoQuarto = isset($_POST['DescricaoQuarto']) ? filter_input(INPUT_POST, 'DescricaoQuarto', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$Ocupado = isset($_POST['Ocupado']) ? filter_input(INPUT_POST, 'Ocupado', FILTER_SANITIZE_NUMBER_INT) : "";

// Variáveis relacionadas aos clientes
$NomeCliente = isset($_POST['NomeCliente']) ? filter_input(INPUT_POST, 'NomeCliente', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$Endereco = isset($_POST['Endereco']) ? filter_input(INPUT_POST, 'Endereco', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$Telefone = isset($_POST['Telefone']) ? filter_input(INPUT_POST, 'Telefone', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$Origem = isset($_POST['Origem']) ? filter_input(INPUT_POST, 'Origem', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$MotivoVisita = isset($_POST['MotivoVisita']) ? filter_input(INPUT_POST, 'MotivoVisita', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$Email = isset($_POST['Email']) ? filter_input(INPUT_POST, 'Email', FILTER_VALIDATE_EMAIL) : "";
$RedesSociais = isset($_POST['RedesSociais']) ? filter_input(INPUT_POST, 'RedesSociais', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$Profissao = isset($_POST['Profissao']) ? filter_input(INPUT_POST, 'Profissao', FILTER_SANITIZE_SPECIAL_CHARS) : "";

// Variáveis relacionadas às transações financeiras
$ValorEntrada = isset($_POST['ValorEntrada']) ? filter_input(INPUT_POST, 'ValorEntrada', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$DescricaoEntrada = isset($_POST['DescricaoEntrada']) ? filter_input(INPUT_POST, 'DescricaoEntrada', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$ValorSaida = isset($_POST['ValorSaida']) ? filter_input(INPUT_POST, 'ValorSaida', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$DescricaoSaida = isset($_POST['DescricaoSaida']) ? filter_input(INPUT_POST, 'DescricaoSaida', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$IdCliente = isset($_POST['IdCliente']) ? filter_input(INPUT_POST, 'IdCliente', FILTER_SANITIZE_SPECIAL_CHARS) : "";

// Variáveis relacionadas ao estoque
$NovoNomeProduto = isset($_POST['NovoNomeProduto']) ? filter_input(INPUT_POST, 'NovoNomeProduto', FILTER_SANITIZE_SPECIAL_CHARS) : "";
$NovaQuantidade = isset($_POST['NovaQuantidade']) ? filter_input(INPUT_POST, 'NovaQuantidade', FILTER_SANITIZE_NUMBER_INT) : "";

// Variáveis adicionais específicas do seu sistema podem ser adicionadas aqui

// ...
?>
