<?php

include_once 'ClassCrud.php';

// Instancie a classe ClassCrud
$Crud = new ClassCrud();

// Verifique se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['Acao']) && $_POST['Acao'] === "CadastrarTurma") {
    $nomeTurma = filter_input(INPUT_POST, 'NomeTurma', FILTER_SANITIZE_STRING);

    // Certifique-se de validar e filtrar as entradas do usuário conforme necessário
    if (empty($nomeTurma)) {
        echo "<p>Nome da turma não pode estar vazio.</p>";
    } else {
        // Cadastrar a turma no banco de dados
        $numeroTurma = uniqid(); // Gera um ID único como número da turma

        $resultadoCadastro = $Crud->cadastrarTurma($numeroTurma, $nomeTurma);

        if ($resultadoCadastro) {
            echo "<p>Turma cadastrada com sucesso!</p>";
        } else {
            echo "<p>Ocorreu um erro ao cadastrar a turma.</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Turma</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 1000;
            padding: 0;
        }

        .Banner {
            text-align: center;
            padding: 20px;
            background-color: #444;
            color: white;
        }

        .Nav {
            background-color: #2d315e;
            overflow: hidden;
        }

        .Nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .Nav a:hover {
            background-color: #ddd;
            color: white;
        }

        .Content {
            max-width: 10000px;
            margin: 150px auto;
            padding: 20px;
            background-color: #2d315e;
            border-radius: 1px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            margin-top: 100px;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="Banner">
        <img src="Banner.jpg" alt="Banner">
    </div>
    <div class="Nav">
        <ul>
            <li><a href="turmas.php">Lista de Turmas</a></li>
            <li><a href="cadastro_turma.php">Cadastro de Turma</a></li>
            <li><a href="tela_principal_professor.php">Tela Professor</a></li>
        </ul>
    </div>
    <div class="Content">
        <h1>Cadastro de Turma</h1>

        <form action="cadastro_turma.php" method="POST">
            <input type="hidden" name="Acao" value="CadastrarTurma">
            
            <label for="NomeTurma">Nome da Turma:</label>
            <input type="text" name="NomeTurma" required>

            <input type="submit" value="Cadastrar Turma">
        </form>
    </div>
</body>
</html>
