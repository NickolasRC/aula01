<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Tela de Autenticação</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="Nav">
        <li><a href="index.php">Pagina Inicial</a></li>
    </div>
    
    <div class="container">
        <div class="header">
            <h1>Bem Vindo</h1>
        </div>

        <div class="form-container">
            <form action="processa_login.php" method="POST" class="formulario">
                <label for="email">E-mail:</label>
                <input type="email" name="email" required><br>

                <label for="senha">Senha:</label>
                <input type="password" name="senha" required><br>

                <button type= "submit"> ENTRAR </button>
                <style>
                button {
  padding: 1.3em 3em;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  font-weight: 500;
  color: #000;
  background-color: #fff;
  border: none;
  border-radius: 45px;
  box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease 0s;
  cursor: pointer;
  outline: none;
}

button:hover {
  background-color: #23c483;
  box-shadow: 0px 15px 20px rgba(46, 229, 157, 0.4);
  color: #fff;
  transform: translateY(-7px);
}

button:active {
  transform: translateY(-1px);
}
</style>
                
            </form>
        </div>
    </div>
</body>
</html>