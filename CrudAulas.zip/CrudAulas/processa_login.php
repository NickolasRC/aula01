<?php
session_start();

// Simplesmente criar uma sessão (não recomendado para produção)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION['email'] = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);

    // Redirecionar para a tela principal do professor (substitua com o URL desejado)
    header("Location: tela_principal_professor.php");
    exit;
} else {
    // Redirecionar em caso de acesso indevido
    header("Location: index.php?error=invalid_request");
    exit;
}
?>