<!DOCTYPE html>
<html>
<head>
    <title>Tela de Atividades da Turma</title>
</head>
<body>
    <h1>Bem-vindo, <span id="professorName"></span>!</h1>
    <button onclick="logout()">Sair</button>
    <button onclick="cadastrarAtividade()">Cadastrar Atividade</button>

    <h2>Atividades</h2>
    <div id="atividades"></div>
</body>
<script>
    // Substitua isso pelo nome do professor autenticado
    var professorName = "Nome do Professor";
    document.getElementById("professorName").innerText = professorName;

    // Substitua isso por uma chamada para o seu backend para obter as atividades
    var atividades = [
        { numero: 1, descricao: "Atividade 1" },
        { numero: 2, descricao: "Atividade 2" }
    ];

    var atividadesDiv = document.getElementById("atividades");
    atividades.forEach(function(atividade) {
        var atividadeDiv = document.createElement("div");
        atividadeDiv.innerText = "Número: " + atividade.numero + ", Descrição: " + atividade.descricao;
        atividadesDiv.appendChild(atividadeDiv);
    });

    function logout() {
        // Adicione aqui a lógica para sair
    }

    function cadastrarAtividade() {
        // Adicione aqui a lógica para ir para o cadastro de atividade
    }
</script>
</html>
